import requests
import time
import base64
from urllib.parse import quote
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class FortiGateConfig:
    """
    This class is used to communicate with FGT through https port.
    """
    def __init__(self, host_ip, log_header, login_port="",
                 username="admin", password="", api_token="", log_level="NONE"):
        self.host_ip = host_ip
        self.login_port = str(login_port)
        self.session = requests.Session()
        self.cookie = ""
        self.csrf_token = ""
        self.log_header = log_header
        self.timeout_sec = 10
        # Specify user/passwd in the beginning, so it is easy to relogin.
        self.username = username
        self.password = password
        self.api_token = api_token
        self.print_log_level = self._get_log_level(log_level, default_level=0)
        self.version = ""

    def send_one_request(self, url, header, data={}, task_name="", attempt_id=0, method="post", params=None):
        response = requests.Response()
        self._log(f"[Task {task_name}] [Attempt {attempt_id}] [Request] URL {url} | Header {header} | DATA {data}", "DEBUG")
        try:
            if method=="post":
                response = self.session.post(url, headers=header, params=params, json=data, verify=False, timeout=self.timeout_sec)
            elif method=="get":
                response = self.session.get(url, headers=header, params=params, data=data, verify=False, timeout=self.timeout_sec)
            self._log("[Task {}] [Attempt {}] [Response] Code {} | Text {} | Header {}".format(task_name, attempt_id, response.status_code,
                                                                        str(response.text).replace("\n", ""),
                                                                        str(response.headers).replace("\n", "")),"DEBUG")
        except Exception as e:
            self._log(f"[Task {task_name}] [Attempt {attempt_id}] Fail, {e}.", "DEBUG")
        return response

    def send_request(self, url, header, data={}, task_name="", max_attempt=20, sleep_time=10,
                     success_rc=[200], relogin_rc=[401], params=None):
        attempt_id = 0
        response = requests.Response()
        request_flag = False
        for attempt_id in range(1, max_attempt+1):
            if self.api_token: # use token
                header["Authorization"] = f"Bearer {self.api_token}"
            else: # use username and password
                # If relogin_rc (usually 401), try to login again and get new cookie
                if attempt_id>1 and response.status_code in relogin_rc:
                    self._log("[Task {}] [Attempt {}] Login again due to last response is {}".format(task_name, attempt_id, response.status_code), "DEBUG")
                    self.login()
                    time.sleep(1) # wait for a while to make sure FGT accept the new cookie
                if task_name not in ["change_password_logout"]:
                    header["Cookie"] = self.cookie
                    header["X-CSRFTOKEN"] = self.csrf_token
            response = self.send_one_request(url, header, data, task_name, attempt_id, params=params)
            # check whether the task is success or not
            if response.status_code in success_rc:
                request_flag = True
            if request_flag:
                break
            self._log(f"[Task {task_name}] [Attempt {attempt_id}] Attempt failed. Sleep {sleep_time}s and retry", "DEBUG")
            if attempt_id != max_attempt:
                time.sleep(sleep_time)
        if request_flag and response.status_code != 200:
            self._log(f"[Task {task_name}] Get a non-200 code: {response.status_code}, this code is considered as success for this task.", "DEBUG")            
        return response.status_code in success_rc, response

    def get_url(self, path):
        login_port = ""
        if self.login_port:
            login_port = ":" + self.login_port
        if not path.startswith("/"):
            path = "/" + path
        return "https://" + self.host_ip + login_port + path
    
    def login(self, username="", password="", max_attempt=5):
        if not username:
            username = self.username
        if not password:
            password = self.password
        if username is None or password is None:
            return False, self._generate_response("Username or password is empty.")

        header = {"Content-Type": "application/json"}
        response = requests.Response()
        status = False
        for attempt_id in range(1,1+max_attempt):
            # old method before v7.6.4
            if not self.version or self.version == "7.6.4-":
                url = self.get_url(f"logincheck?username={quote(username)}&secretkey={quote(password)}")
                data = {}
                response = self.send_one_request(url, header, data=data, task_name="login-logincheck", attempt_id=attempt_id)
                if response.status_code == 200:
                    status = self._get_cookie_from_headers(response.headers)
                    if status:
                        self.version = "7.6.4-"
                        break
                time.sleep(1)
            # new method since v7.6.4
            if not self.version or self.version == "7.6.4+":
                url = self.get_url("/api/v2/authentication")
                data = {
                    "username": username,
                    "password": password,
                    "ack_pre_disclaimer": True,
                }
                response = self.send_one_request(url, header, data=data, task_name="login-authentication", attempt_id=attempt_id)
                if response.status_code == 200:
                    status = self._get_cookie_from_headers(response.headers)
                    if status:
                        self.version = "7.6.4+"
                        break
            if attempt_id != max_attempt:
                time.sleep(10)
        return status, response
    
    def upload_license(self, license_source, license_data):
        if license_source not in ["fortiflex", "file"]:
            return False, self._generate_response("variable LICENSE_SOURCE should be 'fortiflex' or 'file'.")
        status, response = self.login()
        if not status:
            return False, response
        header = {"Content-Type": "application/json"}
        if license_source == "fortiflex":
            body = {"token": license_data}
            url = self.get_url("/api/v2/monitor/system/vmlicense/download")
            status, response = self.send_request(url, header, data=body, task_name="upload_license_fortiflex", success_rc=[200,500])
            if response.status_code==500 and "License Token is already used" in response.text:
                return True, response
            return status, response
        elif license_source == "file":                
            body = {"file_content": self._base64_encode(license_data)}
            url = self.get_url("/api/v2/monitor/system/vmlicense/upload")
            return self.send_request(url, header, data=body, task_name="upload_license_file")
        return False, requests.Response()
    
    def upload_config(self, config_data, config_name = "config_data.conf"):
        if not self.api_token:
            status, response = self.login()
            if not status:
                return False, response
        header = {"Content-Type": "application/json"}
        encoded_config_data = self._base64_encode(config_data)
        body = {
            "filename": config_name,
            "file_content" : encoded_config_data
        }
        url = self.get_url("/api/v2/monitor/system/config-script/upload")
        status, response = self.send_request(url, header, data=body, task_name="upload_config", sleep_time=15, success_rc=[200,500])
        return status, response

    def change_init_password(self, old_password, new_password):
        retry_time = 15
        for i in range(retry_time):
            status, response = self.login(password=old_password, max_attempt=1) # only need cookie for FGT 763, 764+
            if not status:
                time.sleep(10)
                continue
            # For FGT since v7.6.4
            if self.version == "7.6.4+":
                status, response = self.change_password_764(old_password, new_password, attempt_id=i+1)
                if status:
                    break
                time.sleep(10)
                continue
            # For FGT before v7.6.3
            status, response = self.change_password_before_763(old_password, new_password, attempt_id=i+1)
            if status:
                break
            time.sleep(1)
            # For FGT v7.6.3
            status, response = self.change_password_763(old_password, new_password, attempt_id=i+1)
            if status:
                break
            if i != retry_time-1:
                time.sleep(10)
        return status, response

    def change_password_764(self, old_password, new_password, attempt_id=1):
        """
        Change password of FGT after v7.6.4
        """
        url = self.get_url("/api/v2/authentication")
        header = {
            "Content-Type": "application/json",
            "Cookie": self.cookie,
            "X-CSRFTOKEN": self.csrf_token
        }
        body = {
            "password": old_password,
            "new_password1": new_password,
            "new_password2": new_password,
            "ack_pre_disclaimer": True
        }
        response = self.send_one_request(url, header, data=body, task_name="change_password_764", attempt_id=attempt_id)
        return "CHANGE_PWD_SUCCESS" in response.text, response

    def change_password_before_763(self, old_password, new_password, attempt_id=1):
        """
        Change password of FGT before v7.6.3
        """
        url = self.get_url("/api/v2/authentication")
        header = {"Content-Type": "application/json"}
        body = {
            "username" : "admin",
            "secretkey" : old_password,
            "ack_pre_disclaimer" : True,
            "ack_post_disclaimer" : True,
            "new_password1" : new_password,
            "new_password2" : new_password,
            "request_key": True
        }
        session_key = ""
        response = self.send_one_request(url, header, data=body, task_name="change_password_before_763", attempt_id=attempt_id)
        if response.status_code == 200:
            response_json = response.json()
            session_key = response_json.get("session_key", "")
        if not session_key:
            return False, response
        body = {"session_key": session_key}
        self.send_request(url, header, data=body, task_name="change_password_logout", max_attempt=1, success_rc=[200,500])
        return True, response

    def change_password_763(self, old_password, new_password, attempt_id=1):
        """
        Change password of FGT after v7.6.3
        """
        url = self.get_url("/loginpwd_change")
        header = {
            "Content-Type": "application/json",
            "X-CSRFTOKEN": self.csrf_token,
            "Cookie": self.cookie
        }
        params = {
            "old_pwd": old_password,
            "pwd1": new_password,
            "pwd2": new_password,
            "confirm": 1
        }
        response = self.send_one_request(url, header, task_name="change_password_763", attempt_id=attempt_id, params=params)
        return "document.location" in response.text, response

    def _generate_response(self, response_text):
        response = requests.Response()
        response._content = response_text.encode('utf-8')
        response.encoding = 'utf-8'
        return response
    
    def _get_cookie_from_headers(self, header):
        if not header:
            return False
        cookie_data = ""
        for key in header:
            if key.lower() == "set-cookie":
                cookie_data = header[key]
                break
        cookie_list = cookie_data.split(",") # separate different cookies by comma
        cookie_list = [item.split(';')[0].strip() for item in cookie_list] # only the first part of the cookie is needed
        for item in cookie_list:
            if "=" in item and (item.startswith("ccsrftoken") or item.startswith("ccsrf_token")):
                self.csrf_token = item.split("=", 1)[1].strip("'").strip('"')
        self.cookie = ";".join(cookie_list)
        return cookie_data != ""
        
    def _base64_encode(self, data):
        if not isinstance(data, bytes):
            data = str(data).encode("ascii")
        return base64.b64encode(data).decode("ascii")

    def _log(self, log_str, log_level="INFO"):
        log_level_int = self._get_log_level(log_level, default_level=3)
        if self.print_log_level>=log_level_int:
            log_level_str = f"[{log_level}]"
            if len(log_level) == 4:
                log_level_str = log_level_str + " "
            print(f"{log_level_str} [{self.log_header}] {log_str}")

    def _get_log_level(self, log_str, default_level=0):
        log_level = {"TRACE": 5, "DEBUG":4, "INFO":3, "WARN": 2, "ERROR": 1, "NONE": 0}
        if log_str is None:
            return default_level
        if isinstance(log_str, int):
            return log_str
        if isinstance(log_str, str):
            if log_str.isdigit():
                return int(log_str)
            return log_level.get(log_str, default_level)
        return default_level
